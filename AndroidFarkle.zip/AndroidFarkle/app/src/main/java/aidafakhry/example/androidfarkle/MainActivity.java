//Author: Aida Fakhry
//Last worked on: 2-18-2022

package aidafakhry.example.androidfarkle;

//importations:
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

//TO DO: Make buttons smaller (picture size)

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton[] buttons = new ImageButton[6];
    int[] buttonState = new int[6];  // int arr to keep track of buttons state
    int[] dieImages = new int[6];
    int[] dieValue = new int[6]; //setting the die value
    final int HOT_DIE = 0;
    final int SCORE_DIE = 1;
    final int LOCKED_DIE = 2;
    Button roll;
    Button score;
    Button stop;
    TextView currentScoreTV; //total score
    TextView totalScoreTV; //current score
    TextView currentRoundTV; //current round
    int currentScore;
    int totalScore;
    int currentRound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttons[0] = (ImageButton) this.findViewById(R.id.imageButton1); //re assign to images
        buttons[1] = (ImageButton) this.findViewById(R.id.imageButton2);
        buttons[2] = (ImageButton) this.findViewById(R.id.imageButton3);
        buttons[3] = (ImageButton) this.findViewById(R.id.imageButton4);
        buttons[4] = (ImageButton) this.findViewById(R.id.imageButton5);
        buttons[5] = (ImageButton) this.findViewById(R.id.imageButton6);
        for (int a = 0; a < buttons.length; a++) {
            System.out.println(a);
            buttons[a].setOnClickListener(this);
            buttons[a].setEnabled(false);
            buttons[a].setBackgroundColor(Color.LTGRAY);             //setting the background color of the buttons

        }

        roll = (Button) this.findViewById(R.id.button1); //rolling button
        roll.setOnClickListener(this);
        score = (Button) this.findViewById(R.id.button2); //score button
        score.setOnClickListener(this);
        score.setEnabled(false); //setting enabled to false
        stop = (Button) this.findViewById(R.id.button3); //stop
        stop.setOnClickListener(this);
        stop.setEnabled(false); //setting stop button to enabled
        currentScoreTV = (TextView) this.findViewById(R.id.textView1);
        totalScoreTV = (TextView) this.findViewById(R.id.textView2);
        currentRoundTV = (TextView) this.findViewById(R.id.textView3);
        //setting up the dyes
        //setting different pictures, too!
        dieImages[0] = R.drawable.one;
        dieImages[1] = R.drawable.two;
        dieImages[2] = R.drawable.three;
        dieImages[3] = R.drawable.four;
        dieImages[4] = R.drawable.five;
        dieImages[5] = R.drawable.six;
    }

    @Override
    public void onClick(View v) {
        if (v.equals(roll)) {
            for (int a = 0; a < buttons.length; a++) {
                if (buttonState[a] == HOT_DIE) {
                    int choice = (int) (Math.random() * 6);
                    dieValue[a] = choice;
                    buttons[a].setImageResource(dieImages[choice]);
                    buttons[a].setEnabled(true);
                    roll.setEnabled(false);
                    score.setEnabled(true);
                    stop.setEnabled(false);
                }
            }
        } else if (v.equals(score)) {
            int[] valueCount = new int[7];
            for (int a = 0; a < buttonState.length; a++) {
                if (buttonState[a] == SCORE_DIE) {
                    valueCount[dieValue[a] + 1]++; //stopped
                }
            }
            if ((valueCount[2] > 0 && valueCount[2] < 3) ||
                    (valueCount[3] > 0 && valueCount[3] < 3) ||
                    (valueCount[4] > 0 && valueCount[4] < 3) ||
                    (valueCount[6] > 0 && valueCount[6] < 3)) {
                //invalid die selected
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setTitle("Invalid Die selected");
                alertDialogBuilder
                        .setMessage("You can only select scoring dice.")
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
            else if (valueCount[1] == 0 && valueCount[2] == 0 &&
                    valueCount[3] == 0 && valueCount[4] == 0 &&
                    valueCount[5] == 0 && valueCount[6] == 0) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setTitle("No Score!");
                alertDialogBuilder
                        .setMessage("Forfeit score and go to next round")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                currentScore = 0;
                                currentRound++;
                                currentScoreTV.setText("Current Score: " + currentScore);
                                currentRoundTV.setText("Current Round:" + currentRound);
                                extracted();
                                dialog.dismiss();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int i) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
            //current score tracking:

            else {
                if (valueCount[1] < 3) {
                    currentScore += (valueCount[1] * 100);
                }
                if (valueCount[5] < 3) {
                    currentScore += (valueCount[5] * 50);
                }
                if (valueCount[1] >= 3) {
                    currentScore += (1000 * (valueCount[1] - 2));
                }
                if (valueCount[2] >= 3) {
                    currentScore += (200 * (valueCount[2] - 2));
                }
                if (valueCount[3] >= 3) {
                    currentScore += (300 * (valueCount[3] - 2));
                }
                if (valueCount[4] >= 3) {
                    currentScore += (400 * (valueCount[4] - 2));
                }
                if (valueCount[5] >= 3) {
                    currentScore += (500 * (valueCount[5] - 2));
                }
                if (valueCount[6] >= 3) {
                    currentScore += (600 * (valueCount[6] - 2));
                }
//read current score txt view:
                currentScoreTV.setText("Current Score: " + currentScore);
                for (int a = 0; a < buttons.length; a++) {
                    if (buttonState[a] == SCORE_DIE) {
                        buttonState[a] = LOCKED_DIE;
                        buttons[a].setBackgroundColor(Color.BLUE);
                        buttons[a].setEnabled(false);
                    }
                }
                int lockedCount = 0;
                for (int a = 0; a < buttons.length; a++) {
                    if (buttonState[a] == LOCKED_DIE) {
                        lockedCount++;
                    }
                }
                if (lockedCount == 6) {
                    for (int a = 0; a < buttons.length; a++) {
                        buttonState[a] = HOT_DIE;
                        buttons[a].setBackgroundColor(Color.LTGRAY);
                    }
                }
            // roll prompts/controls:
            roll.setEnabled(true);
            score.setEnabled(false);
            stop.setEnabled(true);
        }
    }
        else if(v.equals(stop))

    {
        totalScore += currentScore;
        currentScore = 0;
        currentScoreTV.setText("Current Score: " + currentScore);
        totalScoreTV.setText("Total Score: " + totalScore);
        currentRound++;
        currentRoundTV.setText("Current Round:" + currentRound);

        extracted(); //extracted method
    }


         else {
            for (int a = 0; a < buttons.length; a++) {
                if (v.equals(buttons[a])) {
                    if (buttonState[a] == HOT_DIE) {
                        buttons[a].setBackgroundColor(Color.RED);
                        buttonState[a] = SCORE_DIE;
                    }
                    else {
                        buttons[a].setBackgroundColor(Color.LTGRAY);
                        buttonState[a] = HOT_DIE;
                    }
                }
            }
        }
    }

    private void extracted() {
        for (int a = 0; a< buttons.length; a++) {
            buttons[a].setEnabled(false);
            buttonState[a] = HOT_DIE;
            buttons[a].setBackgroundColor(Color.LTGRAY);
        }
        roll.setEnabled(true);
        score.setEnabled(false);
        stop.setEnabled(false);
    }
}
//left off p4
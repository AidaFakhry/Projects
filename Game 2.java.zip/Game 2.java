import java.util.ArrayList; // Importing array list 

/**
 * This class is the main class of the "World of Zuul" application. "World of
 * Zuul" is a very simple, text based adventure game. Users can walk around some
 * scenery. That's all. It should really be extended to make it more
 * interesting!
 * 
 * To play this game, create an instance of this class and call the "play"
 * method.
 * 
 * This main class creates and initialises all the others: it creates all rooms,
 * creates the parser and starts the game. It also evaluates and executes the
 * commands that the parser returns.
 * 
 * @author Michael Kolling and David J. Barnes
 * @version 1.0 (February 2002)
 */

class Game {
	private Parser parser;
	private Room currentRoom;
	Room outside, theatre, pub, lab, office, onetwenty, yogaroom, westwing, gym, computer_science_room, nursery_room,
			math_room, science_room, writing_room, physc_room;
	ArrayList<Item> inventory = new ArrayList<Item>();

	/**
	 * Create the game and initialise its internal map.
	 */
	public Game() {
		createRooms();
		parser = new Parser();
	}

	public static void main(String[] args) {
		Game mygame = new Game();
		mygame.play();
	}

	/**
	 * Create all the rooms and link their exits together.
	 */
	private void createRooms() {

		// create the rooms
		outside = new Room("outside the main entrance of the university");
		theatre = new Room("in a lecture theatre");
		pub = new Room("in the campus pub");
		lab = new Room("in a computing lab");
		office = new Room("in the computing admin office");
		onetwenty = new Room("in the 'coolest place in the world");
		// new rooms
		yogaroom = new Room("you are currently in the yoga room");
		gym = new Room("you are in the gym");
		westwing = new Room("you are in the westwing");
		computer_science_room = new Room("you are in the computer science room");
		nursery_room = new Room("you are in the nursery room");
		math_room = new Room("you are in the math room");
		science_room = new Room("you are in the science room");
		writing_room = new Room("you are in the writing room");
		physc_room = new Room("you are in the physc room");

		// Room Exits from outside [directions]
		outside.setExit("east", theatre);
		outside.setExit("south", lab);
		outside.setExit("west", pub);
		outside.setExit("north", onetwenty);
		outside.setExit("north", yogaroom);
		outside.setExit("north", gym);
		outside.setExit("east", westwing);
		outside.setExit("south", computer_science_room);
		outside.setExit("north", nursery_room);
		outside.setExit("east", math_room);
		outside.setExit("west", science_room);
		outside.setExit("east", writing_room);
		outside.setExit("west", physc_room);

		// Room Exits - set
		theatre.setExit("west", outside);
		pub.setExit("east", outside);
		office.setExit("west", lab);
		onetwenty.setExit("south", outside);
		yogaroom.setExit("south", outside);
		gym.setExit("south", outside);
		westwing.setExit("north", lab);
		computer_science_room.setExit("east", science_room);
		nursery_room.setExit("east", math_room);
		math_room.setExit("south", outside);
		science_room.setExit("north", nursery_room);
		writing_room.setExit("south", outside);
		physc_room.setExit("north", outside);

		// Inventory additions
		currentRoom = outside; // Start game outside

		inventory.add(new Item("Computer,")); // New item: computer
		onetwenty.setItem(new Item("Robot,")); // New item: robot
		onetwenty.setItem(new Item("Cake,")); // New item: cake
		onetwenty.setItem(new Item("Keyboard,")); // New item: keyboard
		onetwenty.setItem(new Item("Water_bottle")); // New item: water bottle

	}

	/**
	 * Main play routine. Loops until end of play.
	 */

	public void play() {
		printWelcome();

		// Enter the main command loop. Here we repeatedly read commands and
		// execute them until the game is over.

		boolean finished = false;
		while (!finished) {
			Command command = parser.getCommand();
			finished = processCommand(command); // loop exists if this is true
		}
		System.out.println("Thank you for playing.  Good bye.");
	}

	/**
	 * Print out the opening message for the player.
	 */
	private void printWelcome() {
		System.out.println();
		System.out.println("Welcome to Adventure!");
		System.out.println("Adventure is a new, incredibly boring adventure game.");
		System.out.println("Type 'help' if you need help.");
		System.out.println();
		System.out.println(currentRoom.getLongDescription());
	}

	/**
	 * Given a command, process (that is: execute) the command. If this command ends
	 * the game, true is returned, otherwise false is returned.
	 */
	private boolean processCommand(Command command) {
		boolean wantToQuit = false;

		if (command.isUnknown()) {
			System.out.println("I don't know what you mean...");
			return false;
		}

		String commandWord = command.getCommandWord(); // commanders/if-statements
		if (commandWord.equals("help")) { // help commander
			printHelp();
		} else if (commandWord.equals("go")) { // go commander
			wantToQuit = goRoom(command);
		} else if (commandWord.equals("quit")) { // quit commander
			wantToQuit = quit(command);
		} else if (commandWord.equals("inventory")) { // inventory commander
			printInventory();
		} else if (commandWord.equals("get")) { // Scanning word for get
			getItem(command); // Returning to get item
		} else if (commandWord.equals("drop")) { // Scanning word for drop
			dropItem(command); // Drop item return
		}
		return wantToQuit;
	}

	private void getItem(Command command) { // Get item command
		if (!command.hasSecondWord()) {
			// If there is no second word, we don't know where to get...
			System.out.println("Get what?");
			return;
		}

		String item = command.getSecondWord(); // String item command

		// Try to leave current room.
		Item newItem = currentRoom.getItem(item); // Gets back item

		if (newItem == null)
			System.out.println("That item is not here!"); // item is not there/null
		else {
			inventory.add(newItem);
			currentRoom.removeItem(item); // removing item
			System.out.println("Picked up:" + item); // Picked up item

		}
	}

	private void dropItem(Command command) { // Get item command
		if (!command.hasSecondWord()) {
			// if there is no second word, we don't know where to drop...
			System.out.println("Drop what?");
			return;
		}

		String item = command.getSecondWord(); // String item command

		// Try to leave current room.
		Item newItem = null; // Null for forloop
		int index = 0; // to drop later
		for (int i = 0; i < inventory.size(); i++) {
			if (inventory.get(i).getDescription().equals(item)) { // Check if it matches
				newItem = inventory.get(i);
				index = i;
			}
		}

		if (newItem == null)
			System.out.println("That item is not in your inventory!"); // item is not there/null
		else {
			inventory.remove(index);
			currentRoom.setItem(new Item(item)); // setting item
			System.out.println("Drop:" + item); // Picked up item

		}
	}

	// inventory method
	private void printInventory() {
		String output = "";
		for (int i = 0; i < inventory.size(); i++) { // inventory size for loop
			output += inventory.get(i).getDescription() + " "; // To get string

		}
		System.out.println("You are carrying");
		System.out.println(output);
	}

	// implementations of user commands:

	/**
	 * Print out some help information. Here we print some stupid, cryptic message
	 * and a list of the command words.
	 */
	private void printHelp() {
		System.out.println("You are lost. You are alone. You wander");
		System.out.println("around at the university.");
		System.out.println();
		System.out.println("Your command words are:");
		parser.showCommands();
	}

	/**
	 * Try to go to one direction. If there is an exit, enter the new room,
	 * otherwise print an error message.
	 */
	private boolean goRoom(Command command) {
		if (!command.hasSecondWord()) {
			// if there is no second word, we don't know where to go...
			System.out.println("Go where?");
			return false;
		}

		String direction = command.getSecondWord();

		// Try to leave current room.
		Room nextRoom = currentRoom.getExit(direction);

		if (nextRoom == null)
			System.out.println("There is no door!");
		else {
			currentRoom = nextRoom;
			System.out.println(currentRoom.getLongDescription());
			// Win condition
			if (currentRoom == nursery_room) {
				System.out.println("You win! Nice.");
				return true;
			}
		}
		return false;
	}

	/**
	 * "Quit" was entered. Check the rest of the command to see whether we really
	 * quit the game. Return true, if this command quits the game, false otherwise.
	 */
	private boolean quit(Command command) {
		if (command.hasSecondWord()) {
			System.out.println("Quit what?"); // Quit command
			return false;
		} else
			return true; // Signal that we want to quit
	}
}


public class Item { // creating class item 

	String description; 
	
	//constructor 
	public Item(String newdescription) { 
		description = newdescription;
	}
	public String getDescription() { 
	return description; // passing back ^ string
	}
}
